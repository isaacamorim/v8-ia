from flask import Blueprint, request, jsonify
from database.oracle_conn import get_db
import logging

laser_bp = Blueprint("laser", __name__, url_prefix="/api/laser")


@laser_bp.route("/sequencing", methods=["GET"])
def get_sequencing():
    operator = request.args.get("operator")
    if not operator:
        return jsonify({"success": False, "error": "Operador não especificado"}), 400

    try:
        conn = get_db()
        cur = conn.cursor()

        # 1) seta o CLIENT_IDENTIFIER para o operador recebido
        cur.execute(
            """
            BEGIN
                DBMS_SESSION.SET_IDENTIFIER(:oper);
            END;
        """,
            oper=operator,
        )

        # 2) consulta a view que já filtra por SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER')
        cur.execute(
            """
            SELECT OF_NUMERO,
                SEQUENCIA,
                QUANTIDADE,
                COD_PRODUTO,
                DESCRICAO_PRODUTO,
                CAMINHO_STEP
            FROM VW_SEQ_LASER
        """
        )
        columns = [col[0].lower() for col in cur.description]
        jobs = [dict(zip(columns, row)) for row in cur.fetchall()]

        logging.info(f"Sequenciamento carregado para operador {operator}")
        return jsonify({"success": True, "jobs": jobs})

    except Exception as e:
        logging.error(f"Erro ao carregar sequenciamento: {e}")
        return jsonify({"success": False, "error": "Erro de banco de dados"}), 500

    finally:
        cur.close()
        conn.close()
