// app.js

// Variáveis globais
let intervaloAtualizacao = null;
let selectedJob = null;

const operatorInput = document.getElementById("operator");
const loadBtn = document.getElementById("loadBtn");
const loadText = document.getElementById("loadText");
const loadSpinner = document.getElementById("loadSpinner");
const jobTable = document.getElementById('jobTable');
const jobBody = document.getElementById('jobBody');

// Ao carregar a página, configure eventos
document.addEventListener('DOMContentLoaded', () => {
    loadBtn.addEventListener('click', loadSequencing);
    operatorInput.addEventListener('input', () => {
        clearInterval(intervaloAtualizacao);
    });
});

const API_BASE = 'http://localhost:5000/api';

// Carrega sequenciamento para o operador
async function loadSequencing() {
    const operatorId = operatorInput.value.trim();
    if (!operatorId) {
        alert('Digite o número do operador.');
        return;
    }

    // Estado de loading
    loadText.style.display = 'none';
    loadSpinner.style.display = 'inline-block';
    loadBtn.disabled = true;

    try {
        const res = await fetch(
            `${API_BASE}/laser/sequencing?operator=${operatorId}`
        );
        const json = await res.json();

        if (!json.success) {
            throw new Error(json.error || 'Erro desconhecido');
        }

        renderJobs(json.jobs);
        iniciarAtualizacaoAutomatica();
    } catch (err) {
        console.error(err);
        alert(`Erro ao buscar sequenciamento: ${err.message}`);
    } finally {
        // Restaura botão
        loadText.style.display = 'inline-block';
        loadSpinner.style.display = 'none';
        loadBtn.disabled = false;
    }
}

// Renderiza a tabela de jobs
function renderJobs(jobs) {
    jobBody.innerHTML = '';

    for (const job of jobs) {
        const fileName = job.stepPath.split('/').pop();
        const row = document.createElement('tr');

        row.innerHTML = `
        <td>${job.of}</td>
        <td>${job.sequencia}</td>
        <td>${job.produto}</td>
        <td>${job.quantidade}</td>
        <td>
        ${job.stepPath
                ? `<a href="${job.stepPath}" target="_blank">${fileName}</a>`
                : '<span style="color:#a00">—</span>'}
        </td>
        <td>
        ${job.stepPath
                ? `<button class="btn" onclick="abrirJob('${job.jobId}')">▶ Iniciar</button>`
                : `<button class="btn" disabled style="opacity:.5;cursor:default">Indisponível</button>`}
        </td>
    `;

        jobBody.appendChild(row);
    }

    jobTable.style.display = jobs.length ? 'table' : 'none';
}

// Atualização automática a cada 30s
function iniciarAtualizacaoAutomatica() {
    clearInterval(intervaloAtualizacao);
    intervaloAtualizacao = setInterval(loadSequencing, 30_000);
}

// Abre (ou copia + abre) o arquivo .STEP
async function abrirJob(jobId) {
    try {
        // 1. Verifica se já existe localmente
        const resp = await fetch(`/api/laser/verificar-arquivo/${jobId}`);
        const { existe, caminho } = await resp.json();

        // 2. Se não existir, copia do servidor
        if (!existe) {
            if (!confirm('Arquivo .STEP não encontrado. Deseja copiar do servidor?')) {
                return;
            }
            const copyRes = await fetch(`/api/laser/copiar-arquivo/${jobId}`, { method: 'POST' });
            if (!copyRes.ok) {
                throw new Error('Falha ao copiar arquivo');
            }
        }

        // 3. Abre no visualizador local
        window.open(`file://${caminho}`, '_blank');
    } catch (err) {
        alert(`Erro: ${err.message}`);
    }
}

// Completa o apontamento enviando o PDF
async function completeJob() {
    if (!selectedJob) {
        alert('Selecione primeiro um job (Iniciar).');
        return;
    }

    // Abre seletor de arquivo PDF
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf';

    input.onchange = async () => {
        const file = input.files[0];
        if (!file) return;

        try {
            const form = new FormData();
            form.append('pdf', file);

            const resp = await fetch(`/api/laser/complete?jobId=${selectedJob}`, {
                method: 'POST',
                body: form
            });
            const json = await resp.json();

            if (!json.success) {
                throw new Error(json.error || 'Erro desconhecido');
            }

            alert('Apontamento concluído com sucesso!');
            loadSequencing();
        } catch (err) {
            alert(`Erro ao concluir apontamento: ${err.message}`);
        }
    };

    input.click();
}

// Notificações do navegador
function mostrarNotificacoes() {
    if (!("Notification" in window)) {
        alert("Notificações não suportadas!");
        return;
    }
    if (Notification.permission !== "granted") {
        Notification.requestPermission();
    }
    new Notification("🛎️ Novas OFs", {
        body: "Você tem novas ordens de fabricação.",
        icon: "/Imgs/logo-notificacao.png"
    });
}

