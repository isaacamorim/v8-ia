# backend/app.py
from flask import Flask, send_from_directory
from flask_cors import CORS
import os

# Import the blueprint for the laser API (prototype version)
from api.laser.controllers import laser_bp

# Define the base directory of the 'laser' project
BASE_PROJECT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
FRONTEND_DIR = os.path.join(BASE_PROJECT_DIR, "front")
IMGS_DIR = os.path.join(BASE_PROJECT_DIR, "imgs")

app = Flask(__name__)

# Enable CORS for all API routes, adjust origins if needed for production
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Register the laser API blueprint (from api.laser.controllers)
app.register_blueprint(laser_bp)  # This blueprint is already prefixed with /api/laser


# Route to serve the main index.html from the 'front' directory
@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


# Route to serve static files from the 'front' directory (CSS, JS, etc.)
@app.route("/<path:filename>")
def serve_static_from_front(filename):
    return send_from_directory(FRONTEND_DIR, filename)


# Route to serve images from the 'imgs' directory
@app.route("/imgs/<path:filename>")
def serve_images(filename):
    return send_from_directory(IMGS_DIR, filename)


if __name__ == "__main__":
    # Make sure to run on 0.0.0.0 to be accessible externally when exposed
    # The default Flask port is 5000
    app.run(host="0.0.0.0", port=5000, debug=True)


# "C:\Users\nh_9\AppData\Local\Programs\Python\Python313\python.exe" "\\10.42.92.192\Diversos\Isaac\compartilhado\Site\SITE HTML\v8 ia\laser\backend\app.py"
