from flask import Blueprint, request, jsonify, send_from_directory
import logging
import os
import pdfplumber
from werkzeug.utils import secure_filename
import datetime
import cx_Oracle # Adicionado para Oracle

# Importar configuração de conexão com o banco
from config.db_config import get_db_connection

laser_bp = Blueprint("laser", __name__, url_prefix="/api/laser")

# MOCK_DATA_FILE = "/home/ubuntu/laser_project/laser/backend/api/database/mock_sequenciamento.json" # Não será mais usado para sequenciamento
STEP_FILES_BASE_DIR = "/home/ubuntu/laser_project/laser/step_files"
UPLOAD_FOLDER = os.path.join(os.getenv("TEMP"), "laser_uploads")  # Caminho Windows

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Função para ler mock_data ainda pode ser útil para apontamentos se não formos direto pro banco com eles
# Por enquanto, vamos focar em ler o sequenciamento do Oracle.

@laser_bp.route("/sequencing", methods=["GET"])
def get_sequencing():
    operator_id_param = request.args.get("operator")
    if not operator_id_param:
        return jsonify({"success": False, "error": "Operador não especificado"}), 400

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Query SQL fornecida pelo usuário
        # Atenção: O usuário mencionou SOC_COLABID para o operador.
        # A query original não filtra por SOC_COLABID, precisaremos adicionar esse filtro.
        # Também, a query original não especifica de qual tabela vem SOC_COLABID no WHERE, mas sim no SELECT.
        # Vamos assumir que o ID do operador corresponde a SOC_COLABID.
        # A query também tem JLB_CODERP, JLB_NOMECB, JRO_UNIMED que não foram mapeados para o frontend ainda.
        # E JFL_CODIGO, JFL_EMPRESA, JFL_CODSEQ que podem ser úteis para o apontamento.

        sql_query = """
        SELECT i.SOC_CODIGO, i.SOC_COLABID, i.SOC_CODIOF, i.SOC_CODSEQ, i.SOC_SEQUEN, i.SOC_EMPRESA,
            i.SOC_QTPROG, 
            p.JRO_PROERP, p.JRO_DESCRI, 
            ofl.JFL_QTREAL, 
            pc.JPC_DESENHO_ENG,
            ofl.JFL_CODIGO AS SOF_OFLANC_VAL -- Adicionado para obter o SOF_OFLANC
        FROM I_SEQ_OF_COLAB i
        JOIN J_OF jof ON jof.JOF_CODIOF = i.SOC_CODIOF AND jof.JOF_EMPRESA = i.SOC_EMPRESA
        JOIN J_PRODUTO p ON p.JRO_PROID = jof.JOF_PROID
        LEFT JOIN J_PRODUTO_COMPLEMENTO pc ON pc.JPC_PROID = jof.JOF_PROID
        LEFT JOIN J_OFLANC ofl ON ofl.JFL_CODIOF = i.SOC_CODIOF AND ofl.JFL_CODSEQ = i.SOC_CODSEQ AND ofl.JFL_EMPRESA = i.SOC_EMPRESA AND ofl.JFL_DATA_EXCLUSAO IS NULL
        WHERE i.SOC_DATA_EXCLUSAO IS NULL
            AND jof.JOF_DATA_EXCLUSAO IS NULL
            AND jof.JOF_DTENCE IS NULL
            AND i.SOC_COLABID = :colab_id 
        ORDER BY i.SOC_EMPRESA, i.SOC_SEQUEN
        """

        # Mapeamento de nomes de colunas do cursor para nomes de chaves desejados
        # Isso é importante porque o frontend espera certos nomes de campos.
        # Os nomes das colunas devem ser em maiúsculas, como o Oracle retorna por padrão.
        cursor.execute(sql_query, colab_id=operator_id_param)
        
        # Obter nomes das colunas do cursor para mapeamento dinâmico
        colnames = [desc[0] for desc in cursor.description]
        
        processed_jobs = []
        for row in cursor:
            row_dict = dict(zip(colnames, row))
            
            # Mapear para a estrutura que o frontend espera
            # O frontend espera "apontamentos": [] para cada job, mesmo que venha do banco
            # Esta parte será preenchida por outra query ou lógica se quisermos mostrar apontamentos existentes na tela de OFs
            # Por agora, o foco é o sequenciamento principal.
            job_data = {
                "of_numero": row_dict.get("SOC_CODIOF"),
                "sequencia": row_dict.get("SOC_SEQUEN"), # SOC_SEQUEN é a sequencia da lista, SOC_CODSEQ é a operacao
                "cod_produto": row_dict.get("JRO_PROERP"),
                "descricao_peca": row_dict.get("JRO_DESCRI"),
                "quantidade_programada": row_dict.get("SOC_QTPROG", 0),
                "quantidade_realizada": row_dict.get("JFL_QTREAL", 0),
                "caminho_step": row_dict.get("JPC_DESENHO_ENG"),
                "apontamentos": [], # Inicialmente vazio, pode ser preenchido depois se necessário
                # Campos adicionais do banco que podem ser úteis para o apontamento:
                "soc_empresa": row_dict.get("SOC_EMPRESA"),
                "soc_codseq": row_dict.get("SOC_CODSEQ"), # Operação da OF
                "sof_oflanc_val": row_dict.get("SOF_OFLANC_VAL") # JFL_CODIGO para SOF_OFLANC
            }
            processed_jobs.append(job_data)

        logging.info(f"Sequenciamento Oracle carregado para operador {operator_id_param}. {len(processed_jobs)} OFs encontradas.")
        return jsonify({"success": True, "jobs": processed_jobs})

    except cx_Oracle.Error as e:
        logging.error(f"Erro Oracle ao buscar sequenciamento: {e}")
        return jsonify({"success": False, "error": f"Erro de banco de dados ao buscar sequenciamento: {e}"}), 500
    except Exception as e:
        logging.error(f"Erro inesperado ao buscar sequenciamento: {e}")
        return jsonify({"success": False, "error": f"Erro inesperado no servidor: {e}"}), 500
    finally:
        if conn:
            cursor.close()
            conn.close()
            logging.debug("Conexão Oracle fechada.")

@laser_bp.route("/get_step_file", methods=["GET"])
def get_step_file():
    file_path = request.args.get("path")
    if not file_path:
        return jsonify({"success": False, "error": "Caminho do arquivo não especificado"}), 400
    
    # Validação de segurança: garantir que o caminho é relativo e dentro de um diretório base seguro.
    # O JPC_DESENHO_ENG pode ser um caminho absoluto ou relativo. Precisamos definir uma base segura.
    # Por enquanto, vamos assumir que o caminho é absoluto e existe no servidor.
    # Idealmente, os arquivos .step deveriam estar em um diretório gerenciado pela aplicação.
    # Se o JPC_DESENHO_ENG for um caminho de rede (ex: \\servidor\pasta\arquivo.step),
    # o servidor Flask precisaria ter acesso a esse caminho.
    # Para este protótipo, vamos assumir que o caminho é local e acessível.

    if not os.path.isabs(file_path):
        # Se for relativo, precisa ser relativo a uma base segura. Por agora, erro.
        # Ou concatenar com STEP_FILES_BASE_DIR se essa for a intenção.
        # return jsonify({"success": False, "error": "Caminho do arquivo .step deve ser absoluto ou gerenciado pela aplicação."}), 400
        # Tentativa de usar STEP_FILES_BASE_DIR se não for absoluto
        # Isso é um palpite, o ideal é que o banco forneça caminhos consistentes.
        logging.warning(f"Caminho do .step não é absoluto: {file_path}. Tentando com base: {STEP_FILES_BASE_DIR}")
        # Este é um comportamento de fallback, o ideal é que o banco forneça caminhos corretos.
        # Se o JPC_DESENHO_ENG for apenas o nome do arquivo, por exemplo.
        # file_path = os.path.join(STEP_FILES_BASE_DIR, os.path.basename(file_path))
        # Por enquanto, vamos manter a lógica original que espera um caminho absoluto ou relativo ao STEP_FILES_BASE_DIR
        # A query SQL parece retornar o caminho completo em JPC_DESENHO_ENG. Se for um caminho de rede, precisará de tratamento especial.
        pass # Permitir caminhos relativos se a lógica abaixo os tratar corretamente

    try:
        # Se o caminho do banco já for absoluto e correto, esta lógica pode ser simplificada.
        # A lógica original tentava compor com STEP_FILES_BASE_DIR, o que pode não ser o caso aqui.
        # Vamos assumir que file_path é o caminho completo e correto do arquivo .step
        if not os.path.exists(file_path):
            logging.error(f"Arquivo .step não encontrado em: {file_path}")
            return jsonify({"success": False, "error": f"Arquivo .step não encontrado no caminho especificado: {file_path}"}), 404
        
        directory = os.path.dirname(file_path)
        filename = os.path.basename(file_path)
        
        # Adicionar uma verificação de segurança mais robusta se os caminhos vierem de fontes não confiáveis
        # ou se houver risco de path traversal. Por agora, confiamos no caminho do banco.
        logging.info(f"Enviando arquivo .step: {filename} do diretório: {directory}")
        return send_from_directory(directory, filename, as_attachment=True)
    except Exception as e:
        logging.error(f"Erro interno ao buscar arquivo .step: {e}")
        return jsonify({"success": False, "error": f"Erro interno ao buscar arquivo .step: {str(e)}"}), 500


@laser_bp.route("/upload_production_report", methods=["POST"])
def upload_production_report():
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "Nenhum arquivo enviado"}), 400
    
    file = request.files['file']
    of_id_str = request.form.get("of_id") # Vem como string
    operador_id_str = request.form.get("operador_id") # Vem como string
    # Dados da OF que podem vir do frontend ou serem buscados novamente se necessário
    soc_empresa_str = request.form.get("soc_empresa") 
    soc_codseq_str = request.form.get("soc_codseq") # Operação da OF
    sof_oflanc_val_str = request.form.get("sof_oflanc_val") # JFL_CODIGO

    if not all([file, of_id_str, operador_id_str, soc_empresa_str, soc_codseq_str, sof_oflanc_val_str]):
        missing_fields = []
        if not file: missing_fields.append("arquivo")
        if not of_id_str: missing_fields.append("of_id")
        if not operador_id_str: missing_fields.append("operador_id")
        if not soc_empresa_str: missing_fields.append("soc_empresa")
        if not soc_codseq_str: missing_fields.append("soc_codseq")
        if not sof_oflanc_val_str: missing_fields.append("sof_oflanc_val")
        return jsonify({"success": False, "error": f"Dados incompletos. Faltando: {', '.join(missing_fields)}"}), 400
    
    if file.filename == '':
        return jsonify({"success": False, "error": "Nenhum arquivo selecionado"}), 400

    if file and file.filename.endswith('.pdf'):
        original_filename = secure_filename(file.filename)
        # Não precisamos mais de um apontamento_id gerado aqui, pois SOF_APONTAOFID é gerado pelo banco.
        temp_pdf_path = os.path.join(UPLOAD_FOLDER, f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}_{original_filename}")
        file.save(temp_pdf_path)
        logging.info(f"Arquivo PDF '{original_filename}' salvo temporariamente como '{os.path.basename(temp_pdf_path)}'")

        conn = None
        try:
            # Placeholders para dados extraídos do PDF
            extracted_time_placeholder_str = "PT1H30M" # Exemplo de formato ISO 8601 Duration, ou apenas minutos como número
            extracted_start_date_placeholder = datetime.datetime.now() # Data de início como objeto datetime
            quantidade_retirada_pdf_placeholder = 1 # Exemplo

            # Lógica de extração do PDF (mantida como placeholder)
            with pdfplumber.open(temp_pdf_path) as pdf:
                full_text = ""
                for page_num, page in enumerate(pdf.pages):
                    logging.debug(f"Extraindo texto da página {page_num + 1} do PDF {original_filename}")
                    page_text = page.extract_text(x_tolerance=1, y_tolerance=1)
                    if page_text:
                        full_text += page_text + "\n"
                
                logging.debug(f"Texto completo extraído do PDF {original_filename}:\n{full_text[:500]}...")
                # Simular extração - SUBSTITUIR PELA LÓGICA REAL
                # Ex: if "tempo total:" in full_text.lower(): extracted_time_placeholder_str = ...
                # Ex: if "data de inicio:" in full_text.lower(): extracted_start_date_placeholder = ...
                # Ex: if "quantidade produzida:" in full_text.lower(): quantidade_retirada_pdf_placeholder = ...
            
            # Calcular SOF_DTAFIM
            # Assumindo que extracted_time_placeholder_str é um tempo em minutos (int) para simplificar
            # Na realidade, precisaria parsear o formato de tempo do PDF
            try:
                # Exemplo: se o tempo for "90" (minutos)
                tempo_em_minutos = 90 # int(extracted_time_placeholder_str) 
                sof_dtafim = extracted_start_date_placeholder + datetime.timedelta(minutes=tempo_em_minutos)
            except ValueError:
                logging.error(f"Não foi possível converter o tempo extraído '{extracted_time_placeholder_str}' para minutos. Usando data de início como data fim.")
                sof_dtafim = extracted_start_date_placeholder

            # Preparar dados para inserção na S_APONTAMENTO_OF
            apontamento_data = {
                "SOF_OFLANC": int(sof_oflanc_val_str),
                "SOF_CODIOF": of_id_str, # Mantido como string se o campo no BD for VARCHAR2
                "SOF_OPERAC": int(soc_codseq_str),
                "SOF_QNTBOA": quantidade_retirada_pdf_placeholder,
                "SOF_DTINIC": extracted_start_date_placeholder,
                "SOF_DTAFIM": sof_dtafim,
                "SOF_STATUS": None, # Não inserir, conforme usuário
                "SOF_CODTUR": 1, # Fixo 1, conforme usuário
                "SOF_OPERAD": int(soc_codseq_str), # Mesmo que SOF_OPERAC, conforme usuário
                "SOF_COLABID": int(operador_id_str),
                "SOF_HISTOR": None, # Em branco, conforme usuário
                "SOF_DATCAD": None, # Gerado pelo banco, conforme usuário
                "SOF_EMPRESA": soc_empresa_str, 
                "SOF_DATA_EXCLUSAO": None # Em branco/NULL, conforme usuário
            }

            conn = get_db_connection()
            cursor = conn.cursor()

            # SQL para inserir na S_APONTAMENTO_OF
            # SOF_APONTAOFID é gerado pelo banco (assumindo trigger ou sequence)
            sql_insert = """
            INSERT INTO S_APONTAMENTO_OF (
                SOF_OFLANC, SOF_CODIOF, SOF_OPERAC, SOF_QNTBOA, SOF_DTINIC, 
                SOF_DTAFIM, SOF_CODTUR, SOF_OPERAD, SOF_COLABID, SOF_EMPRESA
                --, SOF_STATUS, SOF_HISTOR, SOF_DATCAD, SOF_DATA_EXCLUSAO -- Campos não inseridos ou gerados pelo banco
            ) VALUES (
                :sof_oflanc, :sof_codiof, :sof_operac, :sof_qntboa, :sof_dtinic,
                :sof_dtafim, :sof_codtur, :sof_operad, :sof_colabid, :sof_empresa
            )
            """
            cursor.execute(sql_insert, 
                        sof_oflanc=apontamento_data["SOF_OFLANC"],
                        sof_codiof=apontamento_data["SOF_CODIOF"],
                        sof_operac=apontamento_data["SOF_OPERAC"],
                        sof_qntboa=apontamento_data["SOF_QNTBOA"],
                        sof_dtinic=apontamento_data["SOF_DTINIC"],
                        sof_dtafim=apontamento_data["SOF_DTAFIM"],
                        sof_codtur=apontamento_data["SOF_CODTUR"],
                        sof_operad=apontamento_data["SOF_OPERAD"],
                        sof_colabid=apontamento_data["SOF_COLABID"],
                        sof_empresa=apontamento_data["SOF_EMPRESA"]
                        )
            conn.commit()
            logging.info(f"Apontamento para OF {of_id_str} inserido com sucesso na S_APONTAMENTO_OF.")
            
            # Retornar os dados do apontamento inserido para o frontend (ou uma confirmação)
            # O frontend espera um objeto 'apontamento' com os dados que ele vai mostrar na tabela
            # Como SOF_APONTAOFID é gerado pelo banco, não temos ele aqui a menos que usemos RETURNING INTO
            # Por simplicidade, vamos retornar os dados que temos, mais o nome do PDF.
            # O frontend precisará de um ID único para a linha da tabela, mesmo que temporário.
            # Vamos usar o nome do arquivo PDF como um ID temporário para a UI, se necessário.
            returned_apontamento_data = {
                "apontamento_id": f"db_{original_filename}_{datetime.datetime.now().timestamp()}", # ID temporário para UI
                "pdf_filename": original_filename,
                "tempo_extraido": extracted_time_placeholder_str, # Ou o valor real se extraído
                "data_inicio_extraida": extracted_start_date_placeholder.strftime("%Y-%m-%d %H:%M:%S"),
                "produto_id": "N/A", # Precisaria buscar da OF se for mostrar aqui
                "quantidade_programada_of": 0, # Precisaria buscar da OF
                "quantidade_retirada_pdf": quantidade_retirada_pdf_placeholder
            }

            return jsonify({
                "success": True, 
                "message": "Relatório de produção recebido e apontamento registrado no banco.", 
                "apontamento": returned_apontamento_data 
            })

        except cx_Oracle.Error as e:
            logging.error(f"Erro Oracle ao inserir apontamento: {e}")
            if conn: conn.rollback()
            return jsonify({"success": False, "error": f"Erro de banco de dados ao registrar apontamento: {e}"}), 500
        except Exception as e:
            logging.error(f"Erro ao processar o arquivo PDF ou inserir apontamento: {e}")
            if conn: conn.rollback()
            return jsonify({"success": False, "error": f"Erro ao processar PDF ou registrar apontamento: {str(e)}"}), 500
        finally:
            if conn:
                if 'cursor' in locals() and cursor: cursor.close()
                conn.close()
                logging.debug("Conexão Oracle fechada após tentativa de apontamento.")
            if os.path.exists(temp_pdf_path):
                try:
                    os.remove(temp_pdf_path)
                    logging.info(f"Arquivo PDF temporário '{os.path.basename(temp_pdf_path)}' removido.")
                except Exception as e_rm:
                    logging.error(f"Erro ao remover arquivo PDF temporário '{os.path.basename(temp_pdf_path)}': {e_rm}")
    else:
        return jsonify({"success": False, "error": "Formato de arquivo inválido. Apenas PDF é aceito."}), 400


# A rota de DELETE de apontamento precisará ser adaptada para o banco de dados.
# Por enquanto, vamos focar na leitura e inserção.
# Se a exclusão for marcar SOF_DATA_EXCLUSAO, a lógica será um UPDATE.
@laser_bp.route("/apontamento/<operador_id>/<of_id>/<apontamento_id_frontend>", methods=["DELETE"])
def delete_apontamento(operador_id, of_id, apontamento_id_frontend):
    # Esta rota precisará de uma lógica para identificar o apontamento no banco
    # O apontamento_id_frontend é o que o frontend usa para identificar a linha.
    # Precisaremos de um SOF_APONTAOFID real para deletar do banco.
    # Por enquanto, esta funcionalidade ficará desabilitada ou retornará um erro.
    logging.warning(f"A exclusão de apontamentos via API ainda não está implementada para o banco de dados. Recebido: op={operador_id}, of={of_id}, ap_frontend_id={apontamento_id_frontend}")
    return jsonify({"success": False, "error": "Exclusão de apontamento ainda não implementada com banco de dados."}), 501
