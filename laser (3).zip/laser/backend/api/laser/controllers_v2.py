from flask import Blueprint, request, jsonify, send_from_directory
import logging
import os
import pdfplumber
from werkzeug.utils import secure_filename
import datetime
import cx_Oracle # Adicionado para Oracle

# Importar configuração de conexão com o banco
from config.db_config import get_db_connection

laser_bp = Blueprint("laser", __name__, url_prefix="/api/laser")

# MOCK_DATA_FILE = "/home/ubuntu/laser_project/laser/backend/api/database/mock_sequenciamento.json" # Não será mais usado para sequenciamento
STEP_FILES_BASE_DIR = "/home/ubuntu/laser_project/laser/step_files"
UPLOAD_FOLDER = "/tmp/pdf_uploads"

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Função para ler mock_data ainda pode ser útil para apontamentos se não formos direto pro banco com eles
# Por enquanto, vamos focar em ler o sequenciamento do Oracle.

@laser_bp.route("/sequencing", methods=["GET"])
def get_sequencing():
    operator_id_param = request.args.get("operator")
    if not operator_id_param:
        return jsonify({"success": False, "error": "Operador não especificado"}), 400

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Query SQL fornecida pelo usuário
        # Atenção: O usuário mencionou SOC_COLABID para o operador.
        # A query original não filtra por SOC_COLABID, precisaremos adicionar esse filtro.
        # Também, a query original não especifica de qual tabela vem SOC_COLABID no WHERE, mas sim no SELECT.
        # Vamos assumir que o ID do operador corresponde a SOC_COLABID.
        # A query também tem JLB_CODERP, JLB_NOMECB, JRO_UNIMED que não foram mapeados para o frontend ainda.
        # E JFL_CODIGO, JFL_EMPRESA, JFL_CODSEQ que podem ser úteis para o apontamento.

        sql_query = """
        SELECT i.SOC_CODIGO, i.SOC_COLABID, i.SOC_CODIOF, i.SOC_CODSEQ, i.SOC_SEQUEN, i.SOC_EMPRESA,
               i.SOC_QTPROG, 
               p.JRO_PROERP, p.JRO_DESCRI, 
               ofl.JFL_QTREAL, 
               pc.JPC_DESENHO_ENG,
               ofl.JFL_CODIGO AS SOF_OFLANC_VAL -- Adicionado para obter o SOF_OFLANC
          FROM I_SEQ_OF_COLAB i
          JOIN J_OF jof ON jof.JOF_CODIOF = i.SOC_CODIOF AND jof.JOF_EMPRESA = i.SOC_EMPRESA
          JOIN J_PRODUTO p ON p.JRO_PROID = jof.JOF_PROID
          LEFT JOIN J_PRODUTO_COMPLEMENTO pc ON pc.JPC_PROID = jof.JOF_PROID
          LEFT JOIN J_OFLANC ofl ON ofl.JFL_CODIOF = i.SOC_CODIOF AND ofl.JFL_CODSEQ = i.SOC_CODSEQ AND ofl.JFL_EMPRESA = i.SOC_EMPRESA AND ofl.JFL_DATA_EXCLUSAO IS NULL
         WHERE i.SOC_DATA_EXCLUSAO IS NULL
           AND jof.JOF_DATA_EXCLUSAO IS NULL
           AND jof.JOF_DTENCE IS NULL
           AND i.SOC_COLABID = :colab_id 
         ORDER BY i.SOC_EMPRESA, i.SOC_SEQUEN
        """

        # Mapeamento de nomes de colunas do cursor para nomes de chaves desejados
        # Isso é importante porque o frontend espera certos nomes de campos.
        # Os nomes das colunas devem ser em maiúsculas, como o Oracle retorna por padrão.
        cursor.execute(sql_query, colab_id=operator_id_param)
        
        # Obter nomes das colunas do cursor para mapeamento dinâmico
        colnames = [desc[0] for desc in cursor.description]
        
        processed_jobs = []
        for row in cursor:
            row_dict = dict(zip(colnames, row))
            
            # Mapear para a estrutura que o frontend espera
            # O frontend espera "apontamentos": [] para cada job, mesmo que venha do banco
            # Esta parte será preenchida por outra query ou lógica se quisermos mostrar apontamentos existentes na tela de OFs
            # Por agora, o foco é o sequenciamento principal.
            job_data = {
                "of_numero": row_dict.get("SOC_CODIOF"),
                "sequencia": row_dict.get("SOC_SEQUEN"), # SOC_SEQUEN é a sequencia da lista, SOC_CODSEQ é a operacao
                "cod_produto": row_dict.get("JRO_PROERP"),
                "descricao_peca": row_dict.get("JRO_DESCRI"),
                "quantidade_programada": row_dict.get("SOC_QTPROG", 0),
                "quantidade_realizada": row_dict.get("JFL_QTREAL", 0),
                "caminho_step": row_dict.get("JPC_DESENHO_ENG"),
                "apontamentos": [], # Inicialmente vazio, pode ser preenchido depois se necessário
                # Campos adicionais do banco que podem ser úteis para o apontamento:
                "soc_empresa": row_dict.get("SOC_EMPRESA"),
                "soc_codseq": row_dict.get("SOC_CODSEQ"), # Operação da OF
                "sof_oflanc_val": row_dict.get("SOF_OFLANC_VAL") # JFL_CODIGO para SOF_OFLANC
            }
            processed_jobs.append(job_data)

        logging.info(f"Sequenciamento Oracle carregado para operador {operator_id_param}. {len(processed_jobs)} OFs encontradas.")
        return jsonify({"success": True, "jobs": processed_jobs})

    except cx_Oracle.Error as e:
        logging.error(f"Erro Oracle ao buscar sequenciamento: {e}")
        return jsonify({"success": False, "error": f"Erro de banco de dados ao buscar sequenciamento: {e}"}), 500
    except Exception as e:
        logging.error(f"Erro inesperado ao buscar sequenciamento: {e}")
        return jsonify({"success": False, "error": f"Erro inesperado no servidor: {e}"}), 500
    finally:
        if conn:
            cursor.close()
            conn.close()
            logging.debug("Conexão Oracle fechada.")

@laser_bp.route("/get_step_file", methods=["GET"])
def get_step_file():
    file_path = request.args.get("path")
    if not file_path:
        return jsonify({"success": False, "error": "Caminho do arquivo não especificado"}), 400
    
    # Validação de segurança: garantir que o caminho é relativo e dentro de um diretório base seguro.
    # O JPC_DESENHO_ENG pode ser um caminho absoluto ou relativo. Precisamos definir uma base segura.
    # Por enquanto, vamos assumir que o caminho é absoluto e existe no servidor.
    # Idealmente, os arquivos .step deveriam estar em um diretório gerenciado pela aplicação.
    # Se o JPC_DESENHO_ENG for um caminho de rede (ex: \\servidor\pasta\arquivo.step),
    # o servidor Flask precisaria ter acesso a esse caminho.
    # Para este protótipo, vamos assumir que o caminho é local e acessível.

    if not os.path.isabs(file_path):
        # Se for relativo, precisa ser relativo a uma base segura. Por agora, erro.
        # Ou concatenar com STEP_FILES_BASE_DIR se essa for a intenção.
        # return jsonify({"success": False, "error": "Caminho do arquivo .step deve ser absoluto ou gerenciado pela aplicação."}), 400
        # Tentativa de usar STEP_FILES_BASE_DIR se não for absoluto
        # Isso é um palpite, o ideal é que o banco forneça caminhos consistentes.
        logging.warning(f"Caminho do .step não é absoluto: {file_path}. Tentando com base: {STEP_FILES_BASE_DIR}")
        # Este é um comportamento de fallback, o ideal é que o banco forneça caminhos corretos.
        # Se o JPC_DESENHO_ENG for apenas o nome do arquivo, por exemplo.
        # file_path = os.path.join(STEP_FILES_BASE_DIR, os.path.basename(file_path))
        # Por enquanto, vamos manter a lógica original que espera um caminho absoluto ou relativo ao STEP_FILES_BASE_DIR
        # A query SQL parece retornar o caminho completo em JPC_DESENHO_ENG. Se for um caminho de rede, precisará de tratamento especial.
        pass # Permitir caminhos relativos se a lógica abaixo os tratar corretamente

    try:
        # Se o caminho do banco já for absoluto e correto, esta lógica pode ser simplificada.
        # A lógica original tentava compor com STEP_FILES_BASE_DIR, o que pode não ser o caso aqui.
        # Vamos assumir que file_path é o caminho completo e correto do arquivo .step
        if not os.path.exists(file_path):
            logging.error(f"Arquivo .step não encontrado em: {file_path}")
            return jsonify({"success": False, "error": f"Arquivo .step não encontrado no caminho especificado: {file_path}"}), 404
        
        directory = os.path.dirname(file_path)
        filename = os.path.basename(file_path)
        
        # Adicionar uma verificação de segurança mais robusta se os caminhos vierem de fontes não confiáveis
        # ou se houver risco de path traversal. Por agora, confiamos no caminho do banco.
        logging.info(f"Enviando arquivo .step: {filename} do diretório: {directory}")
        return send_from_directory(directory, filename, as_attachment=True)
    except Exception as e:
        logging.error(f"Erro interno ao buscar arquivo .step: {e}")
        return jsonify({"success": False, "error": f"Erro interno ao buscar arquivo .step: {str(e)}"}), 500


@laser_bp.route("/upload_production_report", methods=["POST"])
def upload_production_report():
    if 'file' not in request.files:
        return jsonify({"success": False, "error": "Nenhum arquivo enviado"}), 400
    
    file = request.files['file']
    of_id_str = request.form.get("of_id") # Vem como string
    operador_id_str = request.form.get("operador_id") # Vem como string
    # Dados da OF que podem vir do frontend ou serem buscados novamente se necessário
    soc_empresa_str = request.form.get("soc_empresa") 
    soc_codseq_str = request.form.get("soc_codseq") # Operação da OF
    sof_oflanc_val_str = request.form.get("sof_oflanc_val") # JFL_CODIGO

    if not all([file, of_id_str, operador_id_str, soc_empresa_str, soc_codseq_str, sof_oflanc_val_str]):
        missing_fields = []
        if not file: missing_fields.append("arquivo")
        if not of_id_str: missing_fields.append("of_id")
        if not operador_id_str: missing_fields.append("operador_id")
        if not soc_empresa_str: missing_fields.append("soc_empresa")
        if not soc_codseq_str: missing_fields.append("soc_codseq")
        if not sof_oflanc_val_str: missing_fields.append("sof_oflanc_val")
        return jsonify({"success": False, "error": f"Dados incompletos. Faltando: {', '.join(missing_fields)}"}), 400
    
    if file.filename == '':
        return jsonify({"success": False, "error": "Nenhum arquivo selecionado"}), 400

    if file and file.filename.endswith('.pdf'):
        original_filename = secure_filename(file.filename)
        # Não precisamos mais de um apontamento_id gerado aqui, pois SOF_APONTAOFID é gerado pelo banco.
        temp_pdf_path = os.path.join(UPLOAD_FOLDER, f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}_{original_filename}")
        file.save(temp_pdf_path)
        logging.info(f"Arquivo PDF '{original_filename}' salvo temporariamente como '{os.path.basename(temp_pdf_path)}'")

        conn = None
        try:
            # Placeholders para dados extraídos do PDF
            extracted_time_placeholder_str = "PT1H30M" # Exemplo de formato ISO 8601 Duration, ou apenas minutos como número
            extracted_start_date_placeholder = datetime.datetime.now() # Data de início como objeto datetime
            quantidade_retirada_pdf_placeholder = 1 # Exemplo

            # Lógica de extração do PDF (mantida como placeholder)
            with pdfplumber.open(temp_pdf_path) as pdf:
                full_text = ""
                for page_num, page in enumerate(pdf.pages):
                    logging.debug(f"Extraindo texto da página {page_num + 1} do PDF {original_filename}")
                    page_text = page.extract_text(x_tolerance=1, y_tolerance=1)
                    if page_text:
                        full_text += page_text + "\n"
                
                logging.debug(f"Texto completo extraído do PDF {original_filename}:\n{full_text[:500]}...")
                
                # Extração do Part Count (quantidade de peças)
                quantidade_retirada_pdf_placeholder = 0  # Valor padrão caso não encontre
                try:
                    # Procurar por "Part Count" no texto do PDF
                    if "Part Count" in full_text:
                        # Dividir o texto em linhas para análise
                        linhas = full_text.split('\n')
                        for linha in linhas:
                            if "Part Count" in linha:
                                # Tentar extrair o número após "Part Count"
                                # Padrão esperado: algum texto seguido de um número no final da linha
                                partes = linha.strip().split()
                                if partes and partes[-1].isdigit():
                                    quantidade_retirada_pdf_placeholder = int(partes[-1])
                                    logging.info(f"Part Count extraído com sucesso: {quantidade_retirada_pdf_placeholder}")
                                    break
                except Exception as e:
                    logging.error(f"Erro ao extrair Part Count do PDF: {e}")
                    # Manter o valor padrão em caso de erro
                
                # Extração do tempo total (Total Time)
                tempo_total_minutos = 0
                try:
                    if "Total Time" in full_text:
                        linhas = full_text.split('\n')
                        for linha in linhas:
                            if "Total Time" in linha:
                                # Formato esperado: "... Total Time 00:02:15.105"
                                partes = linha.strip().split()
                                for i, parte in enumerate(partes):
                                    if parte == "Time" and i+1 < len(partes):
                                        tempo_str = partes[i+1]
                                        # Converter formato HH:MM:SS.mmm para minutos
                                        if ":" in tempo_str:
                                            tempo_partes = tempo_str.split(':')
                                            if len(tempo_partes) >= 3:
                                                horas = int(tempo_partes[0])
                                                minutos = int(tempo_partes[1])
                                                segundos = float(tempo_partes[2])
                                                tempo_total_minutos = horas * 60 + minutos + segundos / 60
                                                logging.info(f"Tempo total extraído: {tempo_str}, convertido para {tempo_total_minutos} minutos")
                                                break
                except Exception as e:
                    logging.error(f"Erro ao extrair tempo total do PDF: {e}")
                
                # Extração da data de início (Start Time)
                try:
                    if "Start Time" in full_text:
                        linhas = full_text.split('\n')
                        for linha in linhas:
                            if "Start Time" in linha:
                                # Formato esperado: "... Start Time 2025-04-17 15:58:51"
                                partes = linha.strip().split()
                                for i, parte in enumerate(partes):
                                    if parte == "Time" and i+2 < len(partes):
                                        data_str = partes[i+1] + " " + partes[i+2]
                                        try:
                                            extracted_start_date_placeholder = datetime.datetime.strptime(data_str, "%Y-%m-%d %H:%M:%S")
                                            logging.info(f"Data de início extraída: {extracted_start_date_placeholder}")
                                            break
                                        except ValueError:
                                            logging.error(f"Formato de data inválido: {data_str}")
                except Exception as e:
                    logging.error(f"Erro ao extrair data de início do PDF: {e}")
            
                # Calcular SOF_DTAFIM baseado no tempo extraído
                if tempo_total_minutos > 0:
                    sof_dtafim = extra
(Content truncated due to size limit. Use line ranges to read in chunks)
